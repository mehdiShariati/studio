<script src="/assets/js/slug.js"></script>

<script>
    $(function(){
        $('#slug').slug();
    });
</script>
